# Data dictionary template

Complete this table from the actual downloaded source files before running analysis.

| Repository field | Original indicator name | Source | Indicator code / table | Unit | Transformation | Notes |
|---|---|---|---|---|---|---|
| `year` | Calendar year | — | — | Year | None | Expected coverage: 1991–2022 |
| `gdp_growth` | To be verified | To be verified | To be verified | To be verified | To be verified | Source document alternates between GDP and GDP growth rate |
| `hiv_prevalence` | To be verified | To be verified | To be verified | To be verified | To be verified | Define population/age group and whether percentage or count |
| `public_health_spending` | To be verified | To be verified | To be verified | To be verified | To be verified | Clarify spending level and whether nominal, real, or share of GDP |
| `life_expectancy` | Life expectancy at birth (exact series to verify) | To be verified | To be verified | To be verified | To be verified | Confirm years and unit |

Also record the retrieval date, source URL, any missing-value handling, and any revisions applied.
