# Data folder

Place the cleaned annual dataset here after downloading and verifying the source series.

Recommended file name: `nigeria_hiv_economic_growth_1991_2022.csv`

Recommended layout: one row per year, with a `year` column and one column for each study variable (for example, `gdp_growth`, `hiv_prevalence`, `public_health_spending`, and `life_expectancy`).

Do not rename or transform series until the original indicator definitions and units are recorded. Keep raw source files separate from cleaned data when redistribution is permitted. Never commit personal, confidential, or access-restricted data.
