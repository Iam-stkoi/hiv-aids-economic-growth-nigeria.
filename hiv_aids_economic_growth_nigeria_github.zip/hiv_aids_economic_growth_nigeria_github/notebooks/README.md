# Notebooks

Add reproducible notebooks here, for example:

- `01_data_collection_and_cleaning.ipynb`
- `02_exploratory_analysis.ipynb`
- `03_regression_and_diagnostics.ipynb`

Each notebook should explain its inputs, transformations, outputs, and limitations. Do not add notebooks that depend on local absolute file paths.
